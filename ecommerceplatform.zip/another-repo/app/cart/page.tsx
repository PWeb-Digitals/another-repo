'use client'

import { useCart } from '../context/CartContext'
import Link from 'next/link'
import { Minus, Plus, Trash2, ShoppingBag, ArrowRight } from 'lucide-react'
import { formatPrice } from '@/lib/utils'

export default function CartPage() {
  const { items, removeItem, updateQuantity, total, clearCart } = useCart()

  if (items.length === 0) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-16 text-center">
        <ShoppingBag size={64} className="text-gray-200 mx-auto mb-4" />
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Your cart is empty</h1>
        <p className="text-gray-500 mb-6">Add items to your cart to get started.</p>
        <Link href="/products" className="btn-primary inline-flex items-center gap-2 px-6 py-3">
          <ShoppingBag size={18} /> Browse Products
        </Link>
      </div>
    )
  }

  // Group by store
  const storeGroups = items.reduce((acc, item) => {
    if (!acc[item.storeId]) acc[item.storeId] = { storeName: item.storeName, items: [] }
    acc[item.storeId].items.push(item)
    return acc
  }, {} as Record<string, { storeName: string; items: typeof items }>)

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Shopping Cart ({items.length} items)</h1>
        <button onClick={clearCart} className="text-sm text-red-500 hover:text-red-600">Clear all</button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          {Object.entries(storeGroups).map(([storeId, group]) => (
            <div key={storeId} className="card p-4">
              <h3 className="font-semibold text-gray-700 text-sm mb-3 border-b pb-2">{group.storeName}</h3>
              <div className="space-y-3">
                {group.items.map(item => (
                  <div key={item.productId} className="flex items-center gap-3">
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-16 h-16 object-cover rounded-lg flex-shrink-0 bg-gray-100"
                    />
                    <div className="flex-1 min-w-0">
                      <Link href={`/products/${item.slug}`} className="text-sm font-medium text-gray-900 hover:text-primary-600 line-clamp-2">
                        {item.name}
                      </Link>
                      <p className="text-primary-600 font-semibold text-sm mt-0.5">{formatPrice(item.price)}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex items-center border border-gray-200 rounded-lg overflow-hidden">
                        <button
                          onClick={() => updateQuantity(item.productId, item.quantity - 1)}
                          className="px-2 py-1.5 hover:bg-gray-50"
                        >
                          <Minus size={12} />
                        </button>
                        <span className="w-8 text-center text-sm">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.productId, item.quantity + 1)}
                          className="px-2 py-1.5 hover:bg-gray-50"
                        >
                          <Plus size={12} />
                        </button>
                      </div>
                      <span className="text-sm font-semibold w-24 text-right">
                        {formatPrice(item.price * item.quantity)}
                      </span>
                      <button onClick={() => removeItem(item.productId)} className="text-red-400 hover:text-red-600 ml-1">
                        <Trash2 size={15} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div>
          <div className="card p-5 sticky top-20">
            <h2 className="font-semibold text-gray-900 mb-4">Order Summary</h2>
            <div className="space-y-2 mb-4 text-sm">
              {Object.values(storeGroups).map(group => (
                <div key={group.storeName} className="flex justify-between text-gray-500">
                  <span>{group.storeName}</span>
                  <span>{formatPrice(group.items.reduce((s, i) => s + i.price * i.quantity, 0))}</span>
                </div>
              ))}
            </div>
            <div className="border-t pt-3 flex justify-between font-bold text-lg mb-4">
              <span>Total</span>
              <span className="text-primary-600">{formatPrice(total)}</span>
            </div>
            <Link href="/checkout" className="btn-primary w-full py-3 flex items-center justify-center gap-2">
              Proceed to Checkout <ArrowRight size={16} />
            </Link>
            <Link href="/products" className="btn-secondary w-full py-2 text-center text-sm mt-2 block">
              Continue Shopping
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
