'use client'

import { useState } from 'react'
import { signIn } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { ShoppingBag, Store, Eye, EyeOff } from 'lucide-react'

export default function RegisterPage() {
  const router = useRouter()
  const [step, setStep] = useState<'role' | 'form'>('role')
  const [role, setRole] = useState<'BUYER' | 'VENDOR'>('BUYER')
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({
    name: '',
    email: '',
    password: '',
    storeName: '',
    storeDescription: '',
  })

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (form.password.length < 6) {
      setError('Password must be at least 6 characters')
      return
    }
    if (role === 'VENDOR' && !form.storeName.trim()) {
      setError('Store name is required')
      return
    }

    setLoading(true)
    setError('')

    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...form, role }),
    })
    const data = await res.json()

    if (!res.ok) {
      setError(data.error || 'Registration failed')
      setLoading(false)
      return
    }

    const signInResult = await signIn('credentials', {
      email: form.email,
      password: form.password,
      redirect: false,
    })

    if (signInResult?.error) {
      router.push('/auth/login')
    } else {
      router.push(role === 'VENDOR' ? '/vendor' : '/dashboard')
      router.refresh()
    }
  }

  if (step === 'role') {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center py-12 px-4">
        <div className="card p-8 w-full max-w-md">
          <div className="text-center mb-6">
            <h1 className="text-2xl font-bold text-gray-900">Create an account</h1>
            <p className="text-gray-500 mt-1 text-sm">How do you want to use MarketHub?</p>
          </div>

          <div className="space-y-3">
            <button
              onClick={() => { setRole('BUYER'); setStep('form') }}
              className="w-full flex items-start gap-4 p-4 border-2 border-gray-200 hover:border-primary-500 rounded-xl transition-colors group"
            >
              <div className="p-2 bg-primary-50 rounded-lg group-hover:bg-primary-100">
                <ShoppingBag size={24} className="text-primary-600" />
              </div>
              <div className="text-left">
                <p className="font-semibold text-gray-900">I want to shop</p>
                <p className="text-sm text-gray-500">Browse and buy from multiple vendors</p>
              </div>
            </button>

            <button
              onClick={() => { setRole('VENDOR'); setStep('form') }}
              className="w-full flex items-start gap-4 p-4 border-2 border-gray-200 hover:border-primary-500 rounded-xl transition-colors group"
            >
              <div className="p-2 bg-green-50 rounded-lg group-hover:bg-green-100">
                <Store size={24} className="text-green-600" />
              </div>
              <div className="text-left">
                <p className="font-semibold text-gray-900">I want to sell</p>
                <p className="text-sm text-gray-500">Create a store and sell your products</p>
              </div>
            </button>
          </div>

          <p className="text-center text-sm text-gray-500 mt-5">
            Already have an account?{' '}
            <Link href="/auth/login" className="text-primary-600 font-medium hover:underline">Sign in</Link>
          </p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center py-12 px-4">
      <div className="card p-8 w-full max-w-md">
        <div className="text-center mb-6">
          <h1 className="text-2xl font-bold text-gray-900">
            {role === 'VENDOR' ? 'Create your store' : 'Create your account'}
          </h1>
          <p className="text-gray-500 mt-1 text-sm">
            {role === 'VENDOR' ? 'Start selling on MarketHub' : 'Start shopping on MarketHub'}
          </p>
        </div>

        {error && (
          <div className="bg-red-50 text-red-600 text-sm px-4 py-3 rounded-lg mb-4">{error}</div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
            <input
              type="text"
              required
              className="input"
              placeholder="John Doe"
              value={form.name}
              onChange={e => setForm({ ...form, name: e.target.value })}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
            <input
              type="email"
              required
              className="input"
              placeholder="you@example.com"
              value={form.email}
              onChange={e => setForm({ ...form, email: e.target.value })}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                required
                className="input pr-10"
                placeholder="Min 6 characters"
                value={form.password}
                onChange={e => setForm({ ...form, password: e.target.value })}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
              >
                {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </div>

          {role === 'VENDOR' && (
            <>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Store Name</label>
                <input
                  type="text"
                  required
                  className="input"
                  placeholder="My Awesome Store"
                  value={form.storeName}
                  onChange={e => setForm({ ...form, storeName: e.target.value })}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Store Description <span className="text-gray-400">(optional)</span></label>
                <textarea
                  className="input resize-none"
                  rows={3}
                  placeholder="Describe what you sell..."
                  value={form.storeDescription}
                  onChange={e => setForm({ ...form, storeDescription: e.target.value })}
                />
              </div>
              <p className="text-xs text-amber-600 bg-amber-50 px-3 py-2 rounded-lg">
                Your store will be reviewed by admin before going live.
              </p>
            </>
          )}

          <button type="submit" disabled={loading} className="btn-primary w-full py-2.5">
            {loading ? 'Creating account...' : 'Create Account'}
          </button>
        </form>

        <div className="flex items-center justify-between mt-4 text-sm text-gray-500">
          <button onClick={() => setStep('role')} className="hover:text-gray-700">← Change role</button>
          <Link href="/auth/login" className="text-primary-600 hover:underline">Already have an account?</Link>
        </div>
      </div>
    </div>
  )
}
