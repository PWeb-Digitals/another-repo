import { getServerSession } from 'next-auth'
import { redirect } from 'next/navigation'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import Link from 'next/link'
import { formatPrice } from '@/lib/utils'
import { Users, Store, Package, ShoppingCart } from 'lucide-react'

export const dynamic = 'force-dynamic'

export default async function AdminDashboard() {
  const session = await getServerSession(authOptions)
  if (!session) redirect('/auth/login')

  const user = session.user as any
  if (user.role !== 'ADMIN') redirect('/')

  const [userCount, storeCount, productCount, orderCount, revenue, recentUsers] = await Promise.all([
    prisma.user.count(),
    prisma.store.count(),
    prisma.product.count(),
    prisma.order.count(),
    prisma.order.aggregate({
      where: { status: { in: ['PAID', 'PROCESSING', 'SHIPPED', 'DELIVERED'] } },
      _sum: { total: true },
    }),
    prisma.user.findMany({
      orderBy: { createdAt: 'desc' },
      take: 5,
      select: { id: true, name: true, email: true, role: true, createdAt: true },
    }),
  ])

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Admin Dashboard</h1>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {[
          { label: 'Total Users', value: userCount, icon: Users, color: 'text-primary-600 bg-primary-50' },
          { label: 'Total Stores', value: storeCount, icon: Store, color: 'text-green-600 bg-green-50' },
          { label: 'Total Products', value: productCount, icon: Package, color: 'text-purple-600 bg-purple-50' },
          { label: 'Total Revenue', value: formatPrice(revenue._sum.total || 0), icon: ShoppingCart, color: 'text-orange-600 bg-orange-50' },
        ].map(({ label, value, icon: Icon, color }) => (
          <div key={label} className="card p-4 flex items-center gap-3">
            <div className={`p-2 rounded-lg ${color}`}><Icon size={20} /></div>
            <div>
              <p className="text-xs text-gray-500">{label}</p>
              <p className="font-bold text-gray-900">{value}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="card">
          <div className="flex items-center justify-between px-5 py-4 border-b">
            <h2 className="font-semibold text-gray-900">Recent Users</h2>
          </div>
          <div className="divide-y">
            {recentUsers.map(u => (
              <div key={u.id} className="px-5 py-3 flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-900">{u.name}</p>
                  <p className="text-xs text-gray-500">{u.email}</p>
                </div>
                <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                  u.role === 'ADMIN' ? 'bg-red-100 text-red-700'
                  : u.role === 'VENDOR' ? 'bg-purple-100 text-purple-700'
                  : 'bg-gray-100 text-gray-600'
                }`}>
                  {u.role}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="card p-5">
          <h2 className="font-semibold text-gray-900 mb-4">Admin Actions</h2>
          <div className="space-y-2">
            {[
              { href: '/admin/stores', label: 'Manage Stores', desc: 'Approve or reject vendor stores' },
            ].map(link => (
              <Link key={link.href} href={link.href} className="flex justify-between items-center p-3 rounded-lg hover:bg-gray-50 group">
                <div>
                  <p className="text-sm font-medium text-gray-900 group-hover:text-primary-600">{link.label}</p>
                  <p className="text-xs text-gray-500">{link.desc}</p>
                </div>
                <span className="text-gray-400">→</span>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
