'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { CheckCircle, XCircle } from 'lucide-react'

export default function ApproveStoreButton({ storeId, isApproved }: { storeId: string; isApproved: boolean }) {
  const router = useRouter()
  const [loading, setLoading] = useState(false)

  async function handleToggle() {
    setLoading(true)
    const res = await fetch(`/api/admin/stores/${storeId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ isApproved: !isApproved }),
    })
    if (res.ok) {
      router.refresh()
    } else {
      alert('Action failed')
      setLoading(false)
    }
  }

  if (!isApproved) {
    return (
      <button
        onClick={handleToggle}
        disabled={loading}
        className="flex items-center gap-1.5 px-3 py-1.5 bg-green-600 hover:bg-green-700 text-white text-xs font-medium rounded-lg disabled:opacity-50"
      >
        <CheckCircle size={13} /> Approve
      </button>
    )
  }

  return (
    <button
      onClick={handleToggle}
      disabled={loading}
      className="flex items-center gap-1.5 px-3 py-1.5 border border-red-300 text-red-600 hover:bg-red-50 text-xs font-medium rounded-lg disabled:opacity-50"
    >
      <XCircle size={13} /> Revoke
    </button>
  )
}
