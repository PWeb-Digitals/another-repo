import { getServerSession } from 'next-auth'
import { redirect } from 'next/navigation'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import ApproveStoreButton from './ApproveStoreButton'
import { Store, Package, CheckCircle, XCircle } from 'lucide-react'

export const dynamic = 'force-dynamic'

export default async function AdminStoresPage() {
  const session = await getServerSession(authOptions)
  if (!session) redirect('/auth/login')

  const user = session.user as any
  if (user.role !== 'ADMIN') redirect('/')

  const stores = await prisma.store.findMany({
    include: {
      vendor: { select: { name: true, email: true } },
      _count: { select: { products: true, orders: true } },
    },
    orderBy: { createdAt: 'desc' },
  })

  const pending = stores.filter(s => !s.isApproved)
  const approved = stores.filter(s => s.isApproved)

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Manage Stores</h1>

      {pending.length > 0 && (
        <div className="mb-8">
          <h2 className="text-lg font-semibold text-amber-700 mb-3 flex items-center gap-2">
            <XCircle size={18} /> Pending Approval ({pending.length})
          </h2>
          <div className="space-y-3">
            {pending.map(store => (
              <div key={store.id} className="card p-4 border-amber-200">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-lg overflow-hidden bg-primary-100 flex-shrink-0 flex items-center justify-center">
                      {store.logo ? (
                        <img src={store.logo} alt={store.name} className="w-full h-full object-cover" />
                      ) : (
                        <Store size={20} className="text-primary-400" />
                      )}
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">{store.name}</h3>
                      {store.description && <p className="text-sm text-gray-500 line-clamp-1">{store.description}</p>}
                      <p className="text-xs text-gray-400 mt-0.5">By {store.vendor.name} ({store.vendor.email})</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <ApproveStoreButton storeId={store.id} isApproved={false} />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div>
        <h2 className="text-lg font-semibold text-green-700 mb-3 flex items-center gap-2">
          <CheckCircle size={18} /> Approved Stores ({approved.length})
        </h2>
        <div className="card overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b bg-gray-50">
                <th className="text-left px-4 py-3 font-medium text-gray-600">Store</th>
                <th className="text-left px-4 py-3 font-medium text-gray-600">Vendor</th>
                <th className="text-right px-4 py-3 font-medium text-gray-600">Products</th>
                <th className="text-right px-4 py-3 font-medium text-gray-600">Orders</th>
                <th className="text-right px-4 py-3 font-medium text-gray-600">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {approved.map(store => (
                <tr key={store.id} className="hover:bg-gray-50">
                  <td className="px-4 py-3 font-medium text-gray-900">{store.name}</td>
                  <td className="px-4 py-3 text-gray-500">{store.vendor.name}</td>
                  <td className="px-4 py-3 text-right">
                    <span className="flex items-center justify-end gap-1 text-gray-500">
                      <Package size={13} />{store._count.products}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right text-gray-500">{store._count.orders}</td>
                  <td className="px-4 py-3 text-right">
                    <ApproveStoreButton storeId={store.id} isApproved={true} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
