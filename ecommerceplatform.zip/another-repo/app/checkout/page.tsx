'use client'

import { useState } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { useCart } from '../context/CartContext'
import { formatPrice } from '@/lib/utils'
import PaystackButton from '../components/PaystackButton'

export default function CheckoutPage() {
  const { data: session } = useSession()
  const { items, total, clearCart } = useCart()
  const router = useRouter()

  const [form, setForm] = useState({ address: '', phone: '' })
  const [orderId, setOrderId] = useState<string | null>(null)
  const [orderStep, setOrderStep] = useState<'details' | 'payment' | 'success'>('details')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  if (!session) {
    return (
      <div className="max-w-md mx-auto px-4 py-16 text-center">
        <h1 className="text-2xl font-bold text-gray-900 mb-3">Sign in to checkout</h1>
        <p className="text-gray-500 mb-6">You need to be signed in to place an order.</p>
        <Link href="/auth/login?callbackUrl=/checkout" className="btn-primary inline-flex px-6 py-3">
          Sign In
        </Link>
      </div>
    )
  }

  if (items.length === 0 && orderStep !== 'success') {
    return (
      <div className="max-w-md mx-auto px-4 py-16 text-center">
        <h1 className="text-2xl font-bold text-gray-900 mb-3">Your cart is empty</h1>
        <Link href="/products" className="btn-primary inline-flex px-6 py-3">Browse Products</Link>
      </div>
    )
  }

  if (orderStep === 'success') {
    return (
      <div className="max-w-md mx-auto px-4 py-16 text-center">
        <div className="text-6xl mb-4">🎉</div>
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Order Placed!</h1>
        <p className="text-gray-500 mb-6">Your payment was successful. You can track your orders in your dashboard.</p>
        <div className="flex gap-3 justify-center">
          <Link href="/dashboard/orders" className="btn-primary px-5 py-2.5">View Orders</Link>
          <Link href="/products" className="btn-secondary px-5 py-2.5">Keep Shopping</Link>
        </div>
      </div>
    )
  }

  async function handleCreateOrder() {
    setLoading(true)
    setError('')
    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          items: items.map(i => ({ productId: i.productId, quantity: i.quantity })),
          address: form.address,
          phone: form.phone,
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Failed to create order')

      // Use first order id for payment (multi-store orders each get their own order)
      setOrderId(data.orders[0]?.id || null)
      setOrderStep('payment')
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  async function handlePaymentSuccess(reference: string) {
    // Verify on backend
    await fetch(`/api/payment/verify?reference=${reference}`)
    clearCart()
    setOrderStep('success')
  }

  // Group by store for summary
  const storeGroups = items.reduce((acc, item) => {
    if (!acc[item.storeId]) acc[item.storeId] = { storeName: item.storeName, items: [] }
    acc[item.storeId].items.push(item)
    return acc
  }, {} as Record<string, { storeName: string; items: typeof items }>)

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Checkout</h1>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* Form */}
        <div className="lg:col-span-3 space-y-4">
          {orderStep === 'details' && (
            <div className="card p-5">
              <h2 className="font-semibold text-gray-900 mb-4">Delivery Details</h2>

              {error && (
                <div className="bg-red-50 text-red-600 text-sm px-4 py-3 rounded-lg mb-4">{error}</div>
              )}

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Delivery Address</label>
                  <textarea
                    required
                    className="input resize-none"
                    rows={3}
                    placeholder="Enter your full delivery address"
                    value={form.address}
                    onChange={e => setForm({ ...form, address: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number</label>
                  <input
                    type="tel"
                    required
                    className="input"
                    placeholder="+234 800 000 0000"
                    value={form.phone}
                    onChange={e => setForm({ ...form, phone: e.target.value })}
                  />
                </div>
                <button
                  onClick={handleCreateOrder}
                  disabled={loading || !form.address.trim() || !form.phone.trim()}
                  className="btn-primary w-full py-3"
                >
                  {loading ? 'Processing...' : 'Continue to Payment'}
                </button>
              </div>
            </div>
          )}

          {orderStep === 'payment' && (
            <div className="card p-5">
              <h2 className="font-semibold text-gray-900 mb-2">Payment</h2>
              <p className="text-sm text-gray-500 mb-5">
                Complete your purchase securely with Paystack.
              </p>
              <div className="bg-gray-50 rounded-lg p-3 mb-4 text-sm text-gray-600">
                <p><strong>Delivery to:</strong> {form.address}</p>
                <p className="mt-1"><strong>Phone:</strong> {form.phone}</p>
              </div>
              <PaystackButton
                email={session.user?.email || ''}
                amount={total}
                orderId={orderId || ''}
                onSuccess={handlePaymentSuccess}
                onClose={() => setError('Payment was cancelled.')}
              />
              <button
                onClick={() => { setOrderStep('details'); setOrderId(null) }}
                className="btn-secondary w-full py-2 mt-2 text-sm"
              >
                Back to Details
              </button>
            </div>
          )}
        </div>

        {/* Summary */}
        <div className="lg:col-span-2">
          <div className="card p-5 sticky top-20">
            <h2 className="font-semibold text-gray-900 mb-4">Order Summary</h2>
            <div className="space-y-3 mb-4">
              {items.map(item => (
                <div key={item.productId} className="flex gap-2">
                  <img src={item.image} alt={item.name} className="w-12 h-12 rounded-lg object-cover bg-gray-100 flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-gray-800 line-clamp-1">{item.name}</p>
                    <p className="text-xs text-gray-500">Qty: {item.quantity}</p>
                  </div>
                  <span className="text-sm font-medium">{formatPrice(item.price * item.quantity)}</span>
                </div>
              ))}
            </div>
            <div className="border-t pt-3 space-y-1 text-sm">
              {Object.values(storeGroups).map(g => (
                <div key={g.storeName} className="flex justify-between text-gray-500">
                  <span>{g.storeName}</span>
                  <span>{formatPrice(g.items.reduce((s, i) => s + i.price * i.quantity, 0))}</span>
                </div>
              ))}
              <div className="flex justify-between font-bold text-base pt-2 border-t mt-2">
                <span>Total</span>
                <span className="text-primary-600">{formatPrice(total)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
