import { getServerSession } from 'next-auth'
import { redirect } from 'next/navigation'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import Link from 'next/link'
import { formatPrice } from '@/lib/utils'
import { Package, ShoppingBag, Clock, CheckCircle } from 'lucide-react'

export const dynamic = 'force-dynamic'

export default async function DashboardPage() {
  const session = await getServerSession(authOptions)
  if (!session) redirect('/auth/login')

  const user = session.user as any

  const [orders, totalSpent] = await Promise.all([
    prisma.order.findMany({
      where: { userId: user.id },
      include: {
        items: { include: { product: { select: { name: true, images: true } } } },
        store: { select: { name: true } },
      },
      orderBy: { createdAt: 'desc' },
      take: 5,
    }),
    prisma.order.aggregate({
      where: { userId: user.id, status: { in: ['PAID', 'PROCESSING', 'SHIPPED', 'DELIVERED'] } },
      _sum: { total: true },
    }),
  ])

  const stats = {
    total: await prisma.order.count({ where: { userId: user.id } }),
    pending: await prisma.order.count({ where: { userId: user.id, status: 'PENDING' } }),
    delivered: await prisma.order.count({ where: { userId: user.id, status: 'DELIVERED' } }),
    spent: totalSpent._sum.total || 0,
  }

  const statusColors: Record<string, string> = {
    PENDING: 'bg-yellow-100 text-yellow-700',
    PAID: 'bg-blue-100 text-blue-700',
    PROCESSING: 'bg-indigo-100 text-indigo-700',
    SHIPPED: 'bg-purple-100 text-purple-700',
    DELIVERED: 'bg-green-100 text-green-700',
    CANCELLED: 'bg-red-100 text-red-700',
  }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">My Dashboard</h1>
        <p className="text-gray-500">Welcome back, {session.user?.name}!</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {[
          { label: 'Total Orders', value: stats.total, icon: Package, color: 'text-primary-600 bg-primary-50' },
          { label: 'Pending', value: stats.pending, icon: Clock, color: 'text-yellow-600 bg-yellow-50' },
          { label: 'Delivered', value: stats.delivered, icon: CheckCircle, color: 'text-green-600 bg-green-50' },
          { label: 'Total Spent', value: formatPrice(stats.spent), icon: ShoppingBag, color: 'text-purple-600 bg-purple-50' },
        ].map(({ label, value, icon: Icon, color }) => (
          <div key={label} className="card p-4 flex items-center gap-3">
            <div className={`p-2 rounded-lg ${color}`}>
              <Icon size={20} />
            </div>
            <div>
              <p className="text-xs text-gray-500">{label}</p>
              <p className="font-bold text-gray-900">{value}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="card">
        <div className="flex items-center justify-between px-5 py-4 border-b">
          <h2 className="font-semibold text-gray-900">Recent Orders</h2>
          <Link href="/dashboard/orders" className="text-primary-600 text-sm hover:underline">View all</Link>
        </div>
        {orders.length > 0 ? (
          <div className="divide-y">
            {orders.map(order => (
              <div key={order.id} className="px-5 py-4 flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-900">Order #{order.id.slice(-8).toUpperCase()}</p>
                  <p className="text-xs text-gray-500 mt-0.5">{order.store.name} · {order.items.length} item{order.items.length !== 1 ? 's' : ''}</p>
                  <p className="text-xs text-gray-400">{new Date(order.createdAt).toLocaleDateString()}</p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-semibold text-sm">{formatPrice(order.total)}</span>
                  <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${statusColors[order.status]}`}>
                    {order.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="px-5 py-10 text-center text-gray-400">
            <Package size={40} className="mx-auto mb-2" />
            <p>No orders yet</p>
            <Link href="/products" className="text-primary-600 text-sm hover:underline mt-1 inline-block">Start shopping</Link>
          </div>
        )}
      </div>
    </div>
  )
}
