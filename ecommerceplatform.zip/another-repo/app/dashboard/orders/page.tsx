import { getServerSession } from 'next-auth'
import { redirect } from 'next/navigation'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import Link from 'next/link'
import { formatPrice } from '@/lib/utils'
import { ArrowLeft } from 'lucide-react'

export const dynamic = 'force-dynamic'

const statusColors: Record<string, string> = {
  PENDING: 'bg-yellow-100 text-yellow-700',
  PAID: 'bg-blue-100 text-blue-700',
  PROCESSING: 'bg-indigo-100 text-indigo-700',
  SHIPPED: 'bg-purple-100 text-purple-700',
  DELIVERED: 'bg-green-100 text-green-700',
  CANCELLED: 'bg-red-100 text-red-700',
}

export default async function OrdersPage() {
  const session = await getServerSession(authOptions)
  if (!session) redirect('/auth/login')

  const user = session.user as any

  const orders = await prisma.order.findMany({
    where: { userId: user.id },
    include: {
      items: {
        include: {
          product: { select: { name: true, images: true, slug: true } },
        },
      },
      store: { select: { name: true, slug: true } },
    },
    orderBy: { createdAt: 'desc' },
  })

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <Link href="/dashboard" className="inline-flex items-center gap-1.5 text-sm text-gray-500 hover:text-gray-700 mb-5">
        <ArrowLeft size={14} /> Dashboard
      </Link>
      <h1 className="text-2xl font-bold text-gray-900 mb-6">My Orders</h1>

      {orders.length > 0 ? (
        <div className="space-y-4">
          {orders.map(order => (
            <div key={order.id} className="card">
              <div className="flex items-center justify-between px-5 py-3 border-b bg-gray-50 rounded-t-xl">
                <div>
                  <span className="font-semibold text-sm text-gray-800">Order #{order.id.slice(-8).toUpperCase()}</span>
                  <span className="text-gray-400 mx-2">·</span>
                  <Link href={`/stores/${order.store.slug}`} className="text-sm text-primary-600 hover:underline">{order.store.name}</Link>
                  <span className="text-xs text-gray-400 ml-3">{new Date(order.createdAt).toLocaleDateString('en-NG', { dateStyle: 'medium' })}</span>
                </div>
                <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${statusColors[order.status]}`}>
                  {order.status}
                </span>
              </div>
              <div className="px-5 py-4 space-y-3">
                {order.items.map(item => (
                  <div key={item.id} className="flex gap-3 items-center">
                    <img
                      src={item.product.images[0] || ''}
                      alt={item.product.name}
                      className="w-12 h-12 rounded-lg object-cover bg-gray-100 flex-shrink-0"
                    />
                    <div className="flex-1">
                      <Link href={`/products/${item.product.slug}`} className="text-sm font-medium text-gray-900 hover:text-primary-600">
                        {item.product.name}
                      </Link>
                      <p className="text-xs text-gray-500">Qty: {item.quantity} × {formatPrice(item.price)}</p>
                    </div>
                    <span className="text-sm font-semibold">{formatPrice(item.price * item.quantity)}</span>
                  </div>
                ))}
              </div>
              <div className="px-5 py-3 border-t flex justify-between text-sm">
                <span className="text-gray-500">Order Total</span>
                <span className="font-bold text-primary-600">{formatPrice(order.total)}</span>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-16 text-gray-400">
          <p className="text-lg font-medium">No orders yet</p>
          <Link href="/products" className="text-primary-600 hover:underline mt-2 inline-block text-sm">Browse products</Link>
        </div>
      )}
    </div>
  )
}
