import Link from 'next/link'
import { Search } from 'lucide-react'

export default function NotFound() {
  return (
    <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center px-4">
      <div className="text-center">
        <div className="text-8xl font-bold text-primary-200 mb-4">404</div>
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Page not found</h1>
        <p className="text-gray-500 mb-6">The page you&apos;re looking for doesn&apos;t exist.</p>
        <div className="flex gap-3 justify-center">
          <Link href="/" className="btn-primary px-5 py-2.5">Go Home</Link>
          <Link href="/products" className="btn-secondary px-5 py-2.5 flex items-center gap-2">
            <Search size={16} /> Browse Products
          </Link>
        </div>
      </div>
    </div>
  )
}
