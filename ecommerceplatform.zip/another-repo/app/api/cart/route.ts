import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ items: [] })

  const user = session.user as any
  const items = await prisma.cartItem.findMany({
    where: { userId: user.id },
    include: {
      product: {
        include: { store: { select: { id: true, name: true, slug: true } } },
      },
    },
  })

  return NextResponse.json({ items })
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const user = session.user as any
  const { productId, quantity = 1 } = await req.json()

  const product = await prisma.product.findUnique({ where: { id: productId } })
  if (!product || !product.isActive) {
    return NextResponse.json({ error: 'Product not found' }, { status: 404 })
  }

  const item = await prisma.cartItem.upsert({
    where: { userId_productId: { userId: user.id, productId } },
    update: { quantity: { increment: quantity } },
    create: { userId: user.id, productId, quantity },
  })

  return NextResponse.json(item)
}

export async function DELETE(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const user = session.user as any
  const { searchParams } = new URL(req.url)
  const productId = searchParams.get('productId')

  if (productId) {
    await prisma.cartItem.deleteMany({
      where: { userId: user.id, productId },
    })
  } else {
    await prisma.cartItem.deleteMany({ where: { userId: user.id } })
  }

  return NextResponse.json({ success: true })
}
