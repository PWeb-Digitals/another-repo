import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { initializeTransaction, generateReference } from '@/lib/paystack'
import { prisma } from '@/lib/prisma'

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  try {
    const { email, amount, orderId } = await req.json()

    if (!email || !amount) {
      return NextResponse.json({ error: 'Email and amount are required' }, { status: 400 })
    }

    const reference = generateReference()

    const result = await initializeTransaction({
      email,
      amount,
      reference,
      callback_url: `${process.env.NEXTAUTH_URL}/api/payment/verify`,
      metadata: { orderId, userId: (session.user as any).id },
    })

    // Update order with reference if orderId provided
    if (orderId) {
      await prisma.order.update({
        where: { id: orderId },
        data: { paystackRef: reference },
      }).catch(() => {})
    }

    return NextResponse.json({
      accessCode: result.data.access_code,
      reference: result.data.reference,
      authorizationUrl: result.data.authorization_url,
    })
  } catch (err: any) {
    console.error('Payment init error:', err)
    return NextResponse.json({ error: err.message || 'Payment initialization failed' }, { status: 500 })
  }
}
