import { NextRequest, NextResponse } from 'next/server'
import { verifyTransaction } from '@/lib/paystack'
import { prisma } from '@/lib/prisma'

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const reference = searchParams.get('reference') || searchParams.get('trxref')

  if (!reference) {
    return NextResponse.redirect(new URL('/checkout?error=missing_reference', req.url))
  }

  try {
    const result = await verifyTransaction(reference)
    if (result.data.status === 'success') {
      await prisma.order.updateMany({
        where: { paystackRef: reference },
        data: { status: 'PAID' },
      })
      return NextResponse.redirect(new URL(`/dashboard/orders?success=1&ref=${reference}`, req.url))
    } else {
      return NextResponse.redirect(new URL(`/checkout?error=payment_failed`, req.url))
    }
  } catch (err) {
    console.error('Payment verify error:', err)
    return NextResponse.redirect(new URL('/checkout?error=verification_failed', req.url))
  }
}

export async function POST(req: NextRequest) {
  // Webhook handler
  try {
    const body = await req.json()
    const event = body.event

    if (event === 'charge.success') {
      const reference = body.data.reference
      await prisma.order.updateMany({
        where: { paystackRef: reference },
        data: { status: 'PAID' },
      })
    }

    return NextResponse.json({ received: true })
  } catch (err) {
    console.error('Webhook error:', err)
    return NextResponse.json({ error: 'Webhook processing failed' }, { status: 500 })
  }
}
