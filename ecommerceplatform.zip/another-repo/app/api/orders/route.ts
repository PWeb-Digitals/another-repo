import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const user = session.user as any
  const { searchParams } = new URL(req.url)
  const storeId = searchParams.get('storeId')

  let where: any = {}
  if (user.role === 'ADMIN') {
    if (storeId) where.storeId = storeId
  } else if (user.role === 'VENDOR') {
    const store = await prisma.store.findFirst({ where: { vendorId: user.id } })
    if (!store) return NextResponse.json({ orders: [] })
    where.storeId = store.id
  } else {
    where.userId = user.id
  }

  const orders = await prisma.order.findMany({
    where,
    include: {
      items: { include: { product: { select: { name: true, images: true, slug: true } } } },
      store: { select: { name: true, slug: true } },
      user: { select: { name: true, email: true } },
    },
    orderBy: { createdAt: 'desc' },
  })

  return NextResponse.json({ orders })
}

const createSchema = z.object({
  items: z.array(z.object({
    productId: z.string(),
    quantity: z.number().int().positive(),
  })),
  address: z.string().min(5),
  phone: z.string().min(7),
})

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const user = session.user as any

  try {
    const body = await req.json()
    const data = createSchema.parse(body)

    // Fetch all products
    const productIds = data.items.map(i => i.productId)
    const products = await prisma.product.findMany({
      where: { id: { in: productIds }, isActive: true },
      include: { store: true },
    })

    if (products.length !== productIds.length) {
      return NextResponse.json({ error: 'Some products are unavailable' }, { status: 400 })
    }

    // Group by store
    const storeGroups = new Map<string, typeof products>()
    for (const product of products) {
      const existing = storeGroups.get(product.storeId) || []
      storeGroups.set(product.storeId, [...existing, product])
    }

    const createdOrders = []
    for (const [storeId, storeProducts] of storeGroups) {
      const orderItems = storeProducts.map(p => {
        const item = data.items.find(i => i.productId === p.id)!
        return { productId: p.id, quantity: item.quantity, price: p.price }
      })
      const total = orderItems.reduce((sum, i) => sum + i.price * i.quantity, 0)

      const order = await prisma.order.create({
        data: {
          userId: user.id,
          storeId,
          total,
          address: data.address,
          phone: data.phone,
          items: { createMany: { data: orderItems } },
        },
        include: {
          items: true,
          store: { select: { name: true } },
        },
      })
      createdOrders.push(order)
    }

    return NextResponse.json({ orders: createdOrders }, { status: 201 })
  } catch (err) {
    if (err instanceof z.ZodError) {
      return NextResponse.json({ error: err.errors[0].message }, { status: 400 })
    }
    console.error(err)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
