import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const user = session.user as any
  const order = await prisma.order.findUnique({
    where: { id: params.id },
    include: {
      items: { include: { product: { select: { name: true, images: true, slug: true } } } },
      store: { select: { id: true, name: true, slug: true, vendorId: true } },
      user: { select: { name: true, email: true } },
    },
  })

  if (!order) return NextResponse.json({ error: 'Not found' }, { status: 404 })

  // Only the buyer, vendor, or admin can view the order
  if (order.userId !== user.id && order.store.vendorId !== user.id && user.role !== 'ADMIN') {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }

  return NextResponse.json(order)
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const user = session.user as any
  const order = await prisma.order.findUnique({
    where: { id: params.id },
    include: { store: true },
  })

  if (!order) return NextResponse.json({ error: 'Not found' }, { status: 404 })
  if (order.store.vendorId !== user.id && user.role !== 'ADMIN') {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }

  const { status } = await req.json()
  const updated = await prisma.order.update({
    where: { id: params.id },
    data: { status },
  })

  return NextResponse.json(updated)
}
