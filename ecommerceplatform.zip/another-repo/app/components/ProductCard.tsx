'use client'

import Link from 'next/link'
import { ShoppingCart, Star } from 'lucide-react'
import { formatPrice, calculateDiscount } from '@/lib/utils'
import { useCart } from '../context/CartContext'

interface ProductCardProps {
  id: string
  name: string
  slug: string
  price: number
  comparePrice?: number | null
  images: string[]
  store: { id: string; name: string; slug: string }
  reviews?: { rating: number }[]
  stock: number
}

export default function ProductCard({
  id, name, slug, price, comparePrice, images, store, reviews = [], stock
}: ProductCardProps) {
  const { addItem } = useCart()
  const discount = comparePrice ? calculateDiscount(price, comparePrice) : 0
  const avgRating = reviews.length
    ? reviews.reduce((s, r) => s + r.rating, 0) / reviews.length
    : 0

  function handleAddToCart(e: React.MouseEvent) {
    e.preventDefault()
    addItem({
      productId: id,
      name,
      price,
      image: images[0] || '',
      quantity: 1,
      storeId: store.id,
      storeName: store.name,
      slug,
    })
  }

  return (
    <Link href={`/products/${slug}`} className="card group hover:shadow-md transition-shadow flex flex-col">
      <div className="relative overflow-hidden rounded-t-xl bg-gray-100 aspect-square">
        {images[0] ? (
          <img
            src={images[0]}
            alt={name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-gray-300">
            No Image
          </div>
        )}
        {discount > 0 && (
          <span className="absolute top-2 left-2 bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">
            -{discount}%
          </span>
        )}
        {stock === 0 && (
          <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
            <span className="bg-white text-gray-800 text-xs font-semibold px-3 py-1 rounded-full">Out of Stock</span>
          </div>
        )}
      </div>
      <div className="p-3 flex flex-col flex-1">
        <p className="text-xs text-primary-600 font-medium mb-1">{store.name}</p>
        <h3 className="text-sm font-medium text-gray-900 line-clamp-2 flex-1">{name}</h3>
        {reviews.length > 0 && (
          <div className="flex items-center gap-1 mt-1.5">
            <Star size={12} className="text-yellow-400 fill-yellow-400" />
            <span className="text-xs text-gray-500">{avgRating.toFixed(1)} ({reviews.length})</span>
          </div>
        )}
        <div className="flex items-center justify-between mt-2 gap-2">
          <div>
            <span className="font-bold text-gray-900">{formatPrice(price)}</span>
            {comparePrice && (
              <span className="text-xs text-gray-400 line-through ml-1.5">{formatPrice(comparePrice)}</span>
            )}
          </div>
          <button
            onClick={handleAddToCart}
            disabled={stock === 0}
            className="flex items-center gap-1 bg-primary-600 hover:bg-primary-700 text-white text-xs font-medium px-2.5 py-1.5 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <ShoppingCart size={13} />
            Add
          </button>
        </div>
      </div>
    </Link>
  )
}
