'use client'

import { useState } from 'react'
import { CreditCard } from 'lucide-react'

interface PaystackButtonProps {
  email: string
  amount: number
  orderId: string
  onSuccess: (reference: string) => void
  onClose?: () => void
  disabled?: boolean
  className?: string
  children?: React.ReactNode
}

declare global {
  interface Window {
    PaystackPop: {
      setup: (config: any) => { openIframe: () => void }
    }
  }
}

export default function PaystackButton({
  email, amount, orderId, onSuccess, onClose, disabled, className, children
}: PaystackButtonProps) {
  const [loading, setLoading] = useState(false)

  async function handlePay() {
    setLoading(true)
    try {
      const res = await fetch('/api/payment/initialize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, amount, orderId }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Failed to initialize payment')

      const { accessCode, reference } = data

      if (!window.PaystackPop) {
        await loadPaystackScript()
      }

      const handler = window.PaystackPop.setup({
        key: process.env.NEXT_PUBLIC_PAYSTACK_PUBLIC_KEY,
        email,
        amount: amount * 100,
        ref: reference,
        access_code: accessCode,
        onSuccess: (transaction: { reference: string }) => {
          onSuccess(transaction.reference)
        },
        onClose: () => {
          onClose?.()
        },
      })
      handler.openIframe()
    } catch (err) {
      console.error('Payment error:', err)
      alert('Payment initialization failed. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <button
      onClick={handlePay}
      disabled={disabled || loading}
      className={className || 'btn-primary w-full py-3 flex items-center justify-center gap-2'}
    >
      {loading ? (
        <span className="flex items-center gap-2">
          <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24" fill="none">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
          </svg>
          Processing...
        </span>
      ) : (
        children || (
          <>
            <CreditCard size={18} />
            Pay Now
          </>
        )
      )}
    </button>
  )
}

function loadPaystackScript(): Promise<void> {
  return new Promise((resolve, reject) => {
    if (document.getElementById('paystack-script')) {
      resolve()
      return
    }
    const script = document.createElement('script')
    script.id = 'paystack-script'
    script.src = 'https://js.paystack.co/v1/inline.js'
    script.onload = () => resolve()
    script.onerror = () => reject(new Error('Failed to load Paystack script'))
    document.head.appendChild(script)
  })
}
