import Link from 'next/link'
import { Store, Package } from 'lucide-react'

interface StoreCardProps {
  id: string
  name: string
  slug: string
  description?: string | null
  logo?: string | null
  productCount?: number
}

export default function StoreCard({ id, name, slug, description, logo, productCount = 0 }: StoreCardProps) {
  return (
    <Link href={`/stores/${slug}`} className="card p-5 hover:shadow-md transition-shadow flex flex-col items-center text-center group">
      <div className="w-16 h-16 rounded-full overflow-hidden bg-primary-100 flex items-center justify-center mb-3 flex-shrink-0">
        {logo ? (
          <img src={logo} alt={name} className="w-full h-full object-cover" />
        ) : (
          <Store size={28} className="text-primary-500" />
        )}
      </div>
      <h3 className="font-semibold text-gray-900 group-hover:text-primary-600 transition-colors">{name}</h3>
      {description && (
        <p className="text-sm text-gray-500 mt-1 line-clamp-2">{description}</p>
      )}
      <div className="flex items-center gap-1 mt-3 text-xs text-gray-400">
        <Package size={12} />
        <span>{productCount} product{productCount !== 1 ? 's' : ''}</span>
      </div>
    </Link>
  )
}
