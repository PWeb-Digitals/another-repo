import { Suspense } from 'react'
import { prisma } from '@/lib/prisma'
import ProductCard from '../components/ProductCard'
import { Filter } from 'lucide-react'

export const dynamic = 'force-dynamic'

async function getProducts(params: {
  category?: string
  search?: string
  page?: number
  minPrice?: number
  maxPrice?: number
}) {
  const limit = 12
  const page = params.page || 1
  const where: any = { isActive: true, store: { isApproved: true } }

  if (params.category) where.category = { slug: params.category }
  if (params.search) where.name = { contains: params.search, mode: 'insensitive' }
  if (params.minPrice || params.maxPrice) {
    where.price = {}
    if (params.minPrice) where.price.gte = params.minPrice
    if (params.maxPrice) where.price.lte = params.maxPrice
  }

  const [products, total, categories] = await Promise.all([
    prisma.product.findMany({
      where,
      include: {
        store: { select: { id: true, name: true, slug: true } },
        reviews: { select: { rating: true } },
      },
      skip: (page - 1) * limit,
      take: limit,
      orderBy: { createdAt: 'desc' },
    }),
    prisma.product.count({ where }),
    prisma.category.findMany(),
  ])

  return { products, total, categories, pages: Math.ceil(total / limit) }
}

export default async function ProductsPage({
  searchParams,
}: {
  searchParams: { category?: string; search?: string; page?: string; minPrice?: string; maxPrice?: string }
}) {
  const { products, total, categories, pages } = await getProducts({
    category: searchParams.category,
    search: searchParams.search,
    page: searchParams.page ? parseInt(searchParams.page) : 1,
    minPrice: searchParams.minPrice ? parseFloat(searchParams.minPrice) : undefined,
    maxPrice: searchParams.maxPrice ? parseFloat(searchParams.maxPrice) : undefined,
  })

  const currentPage = searchParams.page ? parseInt(searchParams.page) : 1

  function buildUrl(overrides: Record<string, string | undefined>) {
    const params = new URLSearchParams()
    const merged = { ...searchParams, ...overrides }
    for (const [k, v] of Object.entries(merged)) {
      if (v) params.set(k, v)
    }
    return `/products?${params.toString()}`
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex flex-col md:flex-row gap-6">
        {/* Sidebar */}
        <aside className="md:w-56 flex-shrink-0">
          <div className="card p-4 sticky top-20">
            <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
              <Filter size={16} /> Filters
            </h3>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
              <div className="space-y-1">
                <a
                  href={buildUrl({ category: undefined, page: undefined })}
                  className={`block text-sm px-2 py-1.5 rounded-lg ${!searchParams.category ? 'bg-primary-100 text-primary-700 font-medium' : 'text-gray-600 hover:bg-gray-50'}`}
                >
                  All Categories
                </a>
                {categories.map(cat => (
                  <a
                    key={cat.id}
                    href={buildUrl({ category: cat.slug, page: undefined })}
                    className={`block text-sm px-2 py-1.5 rounded-lg ${searchParams.category === cat.slug ? 'bg-primary-100 text-primary-700 font-medium' : 'text-gray-600 hover:bg-gray-50'}`}
                  >
                    {cat.name}
                  </a>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Price Range</label>
              <form action="/products" className="space-y-2">
                {searchParams.category && <input type="hidden" name="category" value={searchParams.category} />}
                {searchParams.search && <input type="hidden" name="search" value={searchParams.search} />}
                <input
                  type="number"
                  name="minPrice"
                  placeholder="Min (₦)"
                  defaultValue={searchParams.minPrice}
                  className="input text-sm"
                />
                <input
                  type="number"
                  name="maxPrice"
                  placeholder="Max (₦)"
                  defaultValue={searchParams.maxPrice}
                  className="input text-sm"
                />
                <button type="submit" className="btn-primary w-full text-sm py-1.5">Apply</button>
                {(searchParams.minPrice || searchParams.maxPrice) && (
                  <a href={buildUrl({ minPrice: undefined, maxPrice: undefined, page: undefined })} className="btn-secondary w-full text-sm py-1.5 text-center block">
                    Clear
                  </a>
                )}
              </form>
            </div>
          </div>
        </aside>

        {/* Main */}
        <div className="flex-1">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-xl font-bold text-gray-900">
                {searchParams.category
                  ? categories.find(c => c.slug === searchParams.category)?.name || 'Products'
                  : 'All Products'}
              </h1>
              <p className="text-sm text-gray-500 mt-0.5">{total} products found</p>
            </div>
            <form action="/products" className="flex gap-2">
              {searchParams.category && <input type="hidden" name="category" value={searchParams.category} />}
              <input
                type="search"
                name="search"
                placeholder="Search products..."
                defaultValue={searchParams.search}
                className="input text-sm w-48"
              />
              <button type="submit" className="btn-primary text-sm px-3 py-2">Search</button>
            </form>
          </div>

          {products.length > 0 ? (
            <>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                {products.map(p => (
                  <ProductCard
                    key={p.id}
                    id={p.id}
                    name={p.name}
                    slug={p.slug}
                    price={p.price}
                    comparePrice={p.comparePrice}
                    images={p.images}
                    store={p.store}
                    reviews={p.reviews}
                    stock={p.stock}
                  />
                ))}
              </div>

              {pages > 1 && (
                <div className="flex justify-center gap-2 mt-8">
                  {currentPage > 1 && (
                    <a href={buildUrl({ page: String(currentPage - 1) })} className="btn-secondary text-sm px-4 py-2">
                      Previous
                    </a>
                  )}
                  {Array.from({ length: pages }, (_, i) => i + 1).map(p => (
                    <a
                      key={p}
                      href={buildUrl({ page: String(p) })}
                      className={`px-3 py-2 text-sm rounded-lg ${p === currentPage ? 'bg-primary-600 text-white' : 'border border-gray-300 hover:bg-gray-50'}`}
                    >
                      {p}
                    </a>
                  ))}
                  {currentPage < pages && (
                    <a href={buildUrl({ page: String(currentPage + 1) })} className="btn-secondary text-sm px-4 py-2">
                      Next
                    </a>
                  )}
                </div>
              )}
            </>
          ) : (
            <div className="text-center py-16 text-gray-400">
              <p className="text-lg font-medium">No products found</p>
              <p className="text-sm mt-1">Try adjusting your filters</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
