'use client'

import { useState } from 'react'
import { ShoppingCart, Minus, Plus, Check } from 'lucide-react'
import { useCart } from '../../context/CartContext'

interface Props {
  productId: string
  name: string
  price: number
  image: string
  storeId: string
  storeName: string
  slug: string
  stock: number
}

export default function AddToCartButton({ productId, name, price, image, storeId, storeName, slug, stock }: Props) {
  const { addItem } = useCart()
  const [qty, setQty] = useState(1)
  const [added, setAdded] = useState(false)

  function handleAdd() {
    addItem({ productId, name, price, image, quantity: qty, storeId, storeName, slug })
    setAdded(true)
    setTimeout(() => setAdded(false), 2000)
  }

  if (stock === 0) {
    return (
      <button disabled className="w-full py-3 bg-gray-200 text-gray-500 rounded-lg font-medium cursor-not-allowed">
        Out of Stock
      </button>
    )
  }

  return (
    <div className="flex gap-3">
      <div className="flex items-center border border-gray-300 rounded-lg overflow-hidden">
        <button
          onClick={() => setQty(q => Math.max(1, q - 1))}
          className="px-3 py-2 hover:bg-gray-50 transition-colors"
        >
          <Minus size={14} />
        </button>
        <span className="w-10 text-center text-sm font-medium">{qty}</span>
        <button
          onClick={() => setQty(q => Math.min(stock, q + 1))}
          className="px-3 py-2 hover:bg-gray-50 transition-colors"
        >
          <Plus size={14} />
        </button>
      </div>
      <button
        onClick={handleAdd}
        className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg font-medium transition-all ${
          added
            ? 'bg-green-500 text-white'
            : 'bg-primary-600 hover:bg-primary-700 text-white'
        }`}
      >
        {added ? (
          <><Check size={18} /> Added to Cart</>
        ) : (
          <><ShoppingCart size={18} /> Add to Cart</>
        )}
      </button>
    </div>
  )
}
