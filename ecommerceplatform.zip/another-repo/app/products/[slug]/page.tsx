import { notFound } from 'next/navigation'
import { prisma } from '@/lib/prisma'
import { formatPrice, calculateDiscount } from '@/lib/utils'
import AddToCartButton from './AddToCartButton'
import StarRating from '../../components/StarRating'
import Link from 'next/link'
import { Store, Package, ArrowLeft } from 'lucide-react'
import ProductCard from '../../components/ProductCard'

export const dynamic = 'force-dynamic'

export default async function ProductDetailPage({ params }: { params: { slug: string } }) {
  const product = await prisma.product.findUnique({
    where: { slug: params.slug },
    include: {
      store: { select: { id: true, name: true, slug: true, logo: true, description: true } },
      category: true,
      reviews: {
        include: { user: { select: { name: true, image: true } } },
        orderBy: { createdAt: 'desc' },
      },
    },
  })

  if (!product || !product.isActive) notFound()

  const relatedProducts = await prisma.product.findMany({
    where: {
      categoryId: product.categoryId,
      id: { not: product.id },
      isActive: true,
      store: { isApproved: true },
    },
    include: {
      store: { select: { id: true, name: true, slug: true } },
      reviews: { select: { rating: true } },
    },
    take: 4,
  })

  const avgRating = product.reviews.length
    ? product.reviews.reduce((s, r) => s + r.rating, 0) / product.reviews.length
    : 0
  const discount = product.comparePrice ? calculateDiscount(product.price, product.comparePrice) : 0

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <Link href="/products" className="inline-flex items-center gap-1.5 text-sm text-gray-500 hover:text-gray-700 mb-6">
        <ArrowLeft size={14} /> Back to Products
      </Link>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
        {/* Images */}
        <div className="space-y-3">
          <div className="aspect-square bg-gray-100 rounded-xl overflow-hidden">
            {product.images[0] ? (
              <img src={product.images[0]} alt={product.name} className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-gray-300">No Image</div>
            )}
          </div>
          {product.images.length > 1 && (
            <div className="grid grid-cols-4 gap-2">
              {product.images.slice(1, 5).map((img, i) => (
                <div key={i} className="aspect-square bg-gray-100 rounded-lg overflow-hidden">
                  <img src={img} alt={`${product.name} ${i + 2}`} className="w-full h-full object-cover" />
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Details */}
        <div>
          <div className="mb-2">
            <Link href={`/products?category=${product.category.slug}`} className="text-xs text-primary-600 font-medium uppercase tracking-wide hover:underline">
              {product.category.name}
            </Link>
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">{product.name}</h1>

          {product.reviews.length > 0 && (
            <div className="flex items-center gap-2 mb-3">
              <StarRating rating={Math.round(avgRating)} size={16} />
              <span className="text-sm text-gray-500">{avgRating.toFixed(1)} ({product.reviews.length} reviews)</span>
            </div>
          )}

          <div className="flex items-baseline gap-3 mb-4">
            <span className="text-3xl font-bold text-gray-900">{formatPrice(product.price)}</span>
            {product.comparePrice && (
              <>
                <span className="text-lg text-gray-400 line-through">{formatPrice(product.comparePrice)}</span>
                <span className="bg-red-100 text-red-600 text-sm font-bold px-2 py-0.5 rounded-full">{discount}% OFF</span>
              </>
            )}
          </div>

          {product.description && (
            <p className="text-gray-600 mb-5 leading-relaxed">{product.description}</p>
          )}

          <div className="flex items-center gap-2 mb-5 text-sm">
            <Package size={16} className={product.stock > 0 ? 'text-green-500' : 'text-red-400'} />
            <span className={product.stock > 0 ? 'text-green-600 font-medium' : 'text-red-500'}>
              {product.stock > 0 ? `${product.stock} in stock` : 'Out of stock'}
            </span>
          </div>

          <AddToCartButton
            productId={product.id}
            name={product.name}
            price={product.price}
            image={product.images[0] || ''}
            storeId={product.store.id}
            storeName={product.store.name}
            slug={product.slug}
            stock={product.stock}
          />

          {/* Store info */}
          <div className="mt-6 p-4 border border-gray-200 rounded-xl flex items-start gap-3">
            <div className="w-12 h-12 rounded-full overflow-hidden bg-primary-100 flex-shrink-0 flex items-center justify-center">
              {product.store.logo ? (
                <img src={product.store.logo} alt={product.store.name} className="w-full h-full object-cover" />
              ) : (
                <Store size={20} className="text-primary-500" />
              )}
            </div>
            <div>
              <Link href={`/stores/${product.store.slug}`} className="font-semibold text-gray-900 hover:text-primary-600">
                {product.store.name}
              </Link>
              {product.store.description && (
                <p className="text-sm text-gray-500 mt-0.5 line-clamp-2">{product.store.description}</p>
              )}
              <Link href={`/stores/${product.store.slug}`} className="text-primary-600 text-sm hover:underline mt-1 inline-block">
                Visit Store
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Reviews */}
      <section className="mb-12">
        <h2 className="text-xl font-bold text-gray-900 mb-5">Customer Reviews</h2>
        {product.reviews.length > 0 ? (
          <div className="space-y-4">
            {product.reviews.map(review => (
              <div key={review.id} className="card p-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-8 h-8 rounded-full bg-primary-100 flex items-center justify-center text-primary-600 font-semibold text-sm">
                    {review.user.name?.[0] || '?'}
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900">{review.user.name}</p>
                    <StarRating rating={review.rating} size={12} />
                  </div>
                </div>
                {review.comment && <p className="text-sm text-gray-600">{review.comment}</p>}
              </div>
            ))}
          </div>
        ) : (
          <p className="text-gray-500 text-sm">No reviews yet. Be the first to review this product!</p>
        )}
      </section>

      {/* Related */}
      {relatedProducts.length > 0 && (
        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-5">Related Products</h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {relatedProducts.map(p => (
              <ProductCard
                key={p.id}
                id={p.id}
                name={p.name}
                slug={p.slug}
                price={p.price}
                comparePrice={p.comparePrice}
                images={p.images}
                store={p.store}
                reviews={p.reviews}
                stock={p.stock}
              />
            ))}
          </div>
        </section>
      )}
    </div>
  )
}
