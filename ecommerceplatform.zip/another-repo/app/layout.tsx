import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import { Providers } from './providers'
import Navbar from './components/Navbar'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'MarketHub - Multi-Vendor Marketplace',
  description: 'Discover unique products from vendors across Nigeria',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <Providers>
          <Navbar />
          <main className="min-h-screen bg-gray-50">{children}</main>
          <footer className="bg-gray-900 text-gray-300 py-10 mt-16">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div>
                  <h3 className="text-white font-bold text-lg mb-3">MarketHub</h3>
                  <p className="text-sm">Your trusted multi-vendor marketplace for quality products.</p>
                </div>
                <div>
                  <h4 className="text-white font-semibold mb-3">Quick Links</h4>
                  <ul className="space-y-2 text-sm">
                    <li><a href="/products" className="hover:text-white">All Products</a></li>
                    <li><a href="/stores" className="hover:text-white">All Stores</a></li>
                    <li><a href="/auth/register" className="hover:text-white">Become a Vendor</a></li>
                  </ul>
                </div>
                <div>
                  <h4 className="text-white font-semibold mb-3">Support</h4>
                  <ul className="space-y-2 text-sm">
                    <li><a href="#" className="hover:text-white">Contact Us</a></li>
                    <li><a href="#" className="hover:text-white">Terms of Service</a></li>
                    <li><a href="#" className="hover:text-white">Privacy Policy</a></li>
                  </ul>
                </div>
              </div>
              <div className="border-t border-gray-700 mt-8 pt-6 text-center text-sm">
                <p>&copy; {new Date().getFullYear()} MarketHub. All rights reserved.</p>
              </div>
            </div>
          </footer>
        </Providers>
      </body>
    </html>
  )
}
