import { notFound } from 'next/navigation'
import { prisma } from '@/lib/prisma'
import ProductCard from '../../components/ProductCard'
import { Store, Package } from 'lucide-react'

export const dynamic = 'force-dynamic'

export default async function StoreDetailPage({ params }: { params: { slug: string } }) {
  const store = await prisma.store.findUnique({
    where: { slug: params.slug, isApproved: true },
    include: {
      products: {
        where: { isActive: true },
        include: {
          store: { select: { id: true, name: true, slug: true } },
          reviews: { select: { rating: true } },
        },
        orderBy: { createdAt: 'desc' },
      },
      vendor: { select: { name: true, createdAt: true } },
      _count: { select: { products: { where: { isActive: true } } } },
    },
  })

  if (!store) notFound()

  return (
    <div>
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex items-start gap-5">
          <div className="w-20 h-20 rounded-xl overflow-hidden bg-primary-100 flex-shrink-0 flex items-center justify-center">
            {store.logo ? (
              <img src={store.logo} alt={store.name} className="w-full h-full object-cover" />
            ) : (
              <Store size={36} className="text-primary-400" />
            )}
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{store.name}</h1>
            {store.description && <p className="text-gray-500 mt-1 max-w-2xl">{store.description}</p>}
            <div className="flex items-center gap-4 mt-2 text-sm text-gray-400">
              <span className="flex items-center gap-1"><Package size={14} />{store._count.products} products</span>
              <span>Member since {new Date(store.createdAt).getFullYear()}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h2 className="text-lg font-semibold text-gray-900 mb-5">Products</h2>
        {store.products.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {store.products.map(p => (
              <ProductCard
                key={p.id}
                id={p.id}
                name={p.name}
                slug={p.slug}
                price={p.price}
                comparePrice={p.comparePrice}
                images={p.images}
                store={p.store}
                reviews={p.reviews}
                stock={p.stock}
              />
            ))}
          </div>
        ) : (
          <p className="text-gray-500">No products available in this store yet.</p>
        )}
      </div>
    </div>
  )
}
