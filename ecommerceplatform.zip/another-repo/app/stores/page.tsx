import { prisma } from '@/lib/prisma'
import StoreCard from '../components/StoreCard'

export const revalidate = 60

export default async function StoresPage() {
  const stores = await prisma.store.findMany({
    where: { isApproved: true },
    include: { _count: { select: { products: { where: { isActive: true } } } } },
    orderBy: { createdAt: 'desc' },
  })

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">All Stores</h1>
        <p className="text-gray-500 mt-1">{stores.length} verified vendors</p>
      </div>

      {stores.length > 0 ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {stores.map(s => (
            <StoreCard
              key={s.id}
              id={s.id}
              name={s.name}
              slug={s.slug}
              description={s.description}
              logo={s.logo}
              productCount={s._count.products}
            />
          ))}
        </div>
      ) : (
        <p className="text-center text-gray-500 py-16">No stores available yet.</p>
      )}
    </div>
  )
}
