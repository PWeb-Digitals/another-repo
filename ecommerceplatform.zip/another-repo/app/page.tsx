import Link from 'next/link'
import { prisma } from '@/lib/prisma'
import ProductCard from './components/ProductCard'
import StoreCard from './components/StoreCard'
import { ArrowRight, ShoppingBag, Store, Shield } from 'lucide-react'

export const revalidate = 60

async function getFeaturedData() {
  const [products, stores, categories] = await Promise.all([
    prisma.product.findMany({
      where: { isActive: true, store: { isApproved: true } },
      include: {
        store: { select: { id: true, name: true, slug: true } },
        reviews: { select: { rating: true } },
      },
      orderBy: { createdAt: 'desc' },
      take: 8,
    }),
    prisma.store.findMany({
      where: { isApproved: true },
      include: { _count: { select: { products: true } } },
      take: 6,
    }),
    prisma.category.findMany({ take: 8 }),
  ])
  return { products, stores, categories }
}

export default async function HomePage() {
  const { products, stores, categories } = await getFeaturedData()

  return (
    <div>
      {/* Hero */}
      <section className="bg-gradient-to-br from-primary-700 via-primary-600 to-primary-500 text-white py-20 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 leading-tight">
            Shop from Thousands of Vendors
          </h1>
          <p className="text-primary-100 text-lg mb-8 max-w-2xl mx-auto">
            Discover unique products from trusted vendors across Nigeria. Quality guaranteed, fast delivery, secure payments.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link href="/products" className="bg-white text-primary-700 font-semibold px-6 py-3 rounded-lg hover:bg-primary-50 transition-colors inline-flex items-center gap-2">
              <ShoppingBag size={18} /> Browse Products
            </Link>
            <Link href="/auth/register" className="border-2 border-white text-white font-semibold px-6 py-3 rounded-lg hover:bg-white hover:text-primary-700 transition-colors inline-flex items-center gap-2">
              <Store size={18} /> Start Selling
            </Link>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="bg-white border-b py-6">
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-3 gap-4 text-center">
          <div>
            <p className="text-2xl font-bold text-primary-600">{stores.length}+</p>
            <p className="text-sm text-gray-500">Active Stores</p>
          </div>
          <div>
            <p className="text-2xl font-bold text-primary-600">{products.length}+</p>
            <p className="text-sm text-gray-500">Products</p>
          </div>
          <div>
            <p className="text-2xl font-bold text-primary-600">100%</p>
            <p className="text-sm text-gray-500">Secure Payments</p>
          </div>
        </div>
      </section>

      {/* Categories */}
      {categories.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Shop by Category</h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {categories.map(cat => (
              <Link
                key={cat.id}
                href={`/products?category=${cat.slug}`}
                className="relative rounded-xl overflow-hidden aspect-video group"
              >
                {cat.image ? (
                  <img src={cat.image} alt={cat.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                ) : (
                  <div className="w-full h-full bg-primary-100" />
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-3">
                  <span className="text-white font-semibold text-sm">{cat.name}</span>
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}

      {/* Featured Products */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-gray-900">Featured Products</h2>
          <Link href="/products" className="text-primary-600 hover:text-primary-700 text-sm font-medium flex items-center gap-1">
            View all <ArrowRight size={14} />
          </Link>
        </div>
        {products.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {products.map(p => (
              <ProductCard
                key={p.id}
                id={p.id}
                name={p.name}
                slug={p.slug}
                price={p.price}
                comparePrice={p.comparePrice}
                images={p.images}
                store={p.store}
                reviews={p.reviews}
                stock={p.stock}
              />
            ))}
          </div>
        ) : (
          <p className="text-gray-500 text-center py-10">No products available yet.</p>
        )}
      </section>

      {/* Featured Stores */}
      <section className="bg-gray-100 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-900">Our Stores</h2>
            <Link href="/stores" className="text-primary-600 hover:text-primary-700 text-sm font-medium flex items-center gap-1">
              View all <ArrowRight size={14} />
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {stores.map(s => (
              <StoreCard
                key={s.id}
                id={s.id}
                name={s.name}
                slug={s.slug}
                description={s.description}
                logo={s.logo}
                productCount={s._count.products}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Trust badges */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          {[
            { icon: Shield, title: 'Secure Payments', desc: 'All payments processed securely via Paystack' },
            { icon: Store, title: 'Verified Vendors', desc: 'Every store is reviewed before approval' },
            { icon: ShoppingBag, title: 'Easy Returns', desc: 'Hassle-free return policy across all vendors' },
          ].map(({ icon: Icon, title, desc }) => (
            <div key={title} className="flex items-start gap-4 p-5 bg-white rounded-xl border border-gray-100">
              <div className="p-2 bg-primary-50 rounded-lg">
                <Icon size={22} className="text-primary-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900">{title}</h3>
                <p className="text-sm text-gray-500 mt-0.5">{desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  )
}
