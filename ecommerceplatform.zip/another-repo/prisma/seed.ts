import { PrismaClient, Role } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

async function main() {
  console.log('Seeding database...')

  // Create categories
  const categories = await Promise.all([
    prisma.category.upsert({
      where: { slug: 'electronics' },
      update: {},
      create: {
        name: 'Electronics',
        slug: 'electronics',
        image: 'https://images.unsplash.com/photo-1498049794561-7780e7231661?w=400',
      },
    }),
    prisma.category.upsert({
      where: { slug: 'fashion' },
      update: {},
      create: {
        name: 'Fashion',
        slug: 'fashion',
        image: 'https://images.unsplash.com/photo-1558769132-cb1aea458c5e?w=400',
      },
    }),
    prisma.category.upsert({
      where: { slug: 'home-garden' },
      update: {},
      create: {
        name: 'Home & Garden',
        slug: 'home-garden',
        image: 'https://images.unsplash.com/photo-1484154218962-a197022b5858?w=400',
      },
    }),
    prisma.category.upsert({
      where: { slug: 'sports' },
      update: {},
      create: {
        name: 'Sports',
        slug: 'sports',
        image: 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=400',
      },
    }),
    prisma.category.upsert({
      where: { slug: 'books' },
      update: {},
      create: {
        name: 'Books',
        slug: 'books',
        image: 'https://images.unsplash.com/photo-1524995997946-a1c2e315a42f?w=400',
      },
    }),
  ])

  console.log(`Created ${categories.length} categories`)

  // Create admin user
  const adminPassword = await bcrypt.hash('admin123', 10)
  const admin = await prisma.user.upsert({
    where: { email: 'admin@marketplace.com' },
    update: {},
    create: {
      email: 'admin@marketplace.com',
      name: 'Admin User',
      password: adminPassword,
      role: Role.ADMIN,
    },
  })

  // Create demo vendor
  const vendorPassword = await bcrypt.hash('vendor123', 10)
  const vendor = await prisma.user.upsert({
    where: { email: 'vendor@techstore.com' },
    update: {},
    create: {
      email: 'vendor@techstore.com',
      name: 'Tech Store Owner',
      password: vendorPassword,
      role: Role.VENDOR,
    },
  })

  // Create demo buyer
  const buyerPassword = await bcrypt.hash('buyer123', 10)
  const buyer = await prisma.user.upsert({
    where: { email: 'buyer@example.com' },
    update: {},
    create: {
      email: 'buyer@example.com',
      name: 'Demo Buyer',
      password: buyerPassword,
      role: Role.BUYER,
    },
  })

  console.log('Created users:', { admin: admin.email, vendor: vendor.email, buyer: buyer.email })

  // Create demo store
  const store = await prisma.store.upsert({
    where: { slug: 'tech-haven' },
    update: {},
    create: {
      name: 'Tech Haven',
      slug: 'tech-haven',
      description: 'Your one-stop shop for the latest gadgets and electronics at competitive prices.',
      logo: 'https://images.unsplash.com/photo-1611532736597-de2d4265fba3?w=200',
      isApproved: true,
      vendorId: vendor.id,
    },
  })

  // Create second store
  const vendor2Password = await bcrypt.hash('vendor123', 10)
  const vendor2 = await prisma.user.upsert({
    where: { email: 'vendor@fashionboutique.com' },
    update: {},
    create: {
      email: 'vendor@fashionboutique.com',
      name: 'Fashion Boutique Owner',
      password: vendor2Password,
      role: Role.VENDOR,
    },
  })

  const store2 = await prisma.store.upsert({
    where: { slug: 'fashion-boutique' },
    update: {},
    create: {
      name: 'Fashion Boutique',
      slug: 'fashion-boutique',
      description: 'Trendy clothing and accessories for every occasion.',
      logo: 'https://images.unsplash.com/photo-1441984904996-e0b6ba687e04?w=200',
      isApproved: true,
      vendorId: vendor2.id,
    },
  })

  console.log('Created stores:', { store1: store.name, store2: store2.name })

  // Create products for Tech Haven
  const electronics = categories.find(c => c.slug === 'electronics')!
  const fashion = categories.find(c => c.slug === 'fashion')!

  const products = await Promise.all([
    prisma.product.upsert({
      where: { slug: 'wireless-bluetooth-headphones' },
      update: {},
      create: {
        name: 'Wireless Bluetooth Headphones',
        slug: 'wireless-bluetooth-headphones',
        description: 'Premium wireless headphones with active noise cancellation, 30-hour battery life, and crystal-clear audio quality. Perfect for music lovers and professionals.',
        price: 15000,
        comparePrice: 22000,
        stock: 50,
        images: [
          'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600',
          'https://images.unsplash.com/photo-1484704849700-f032a568e944?w=600',
        ],
        categoryId: electronics.id,
        storeId: store.id,
      },
    }),
    prisma.product.upsert({
      where: { slug: 'smart-watch-pro' },
      update: {},
      create: {
        name: 'Smart Watch Pro',
        slug: 'smart-watch-pro',
        description: 'Feature-packed smartwatch with health monitoring, GPS tracking, and 7-day battery life. Compatible with iOS and Android.',
        price: 45000,
        comparePrice: 60000,
        stock: 30,
        images: [
          'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600',
          'https://images.unsplash.com/photo-1434493789847-2f02dc6ca35d?w=600',
        ],
        categoryId: electronics.id,
        storeId: store.id,
      },
    }),
    prisma.product.upsert({
      where: { slug: 'portable-power-bank-20000mah' },
      update: {},
      create: {
        name: 'Portable Power Bank 20000mAh',
        slug: 'portable-power-bank-20000mah',
        description: 'High-capacity power bank with fast charging support. Charge multiple devices simultaneously with its dual USB-A and USB-C ports.',
        price: 8500,
        comparePrice: 12000,
        stock: 100,
        images: [
          'https://images.unsplash.com/photo-1609091839311-d5365f9ff1c5?w=600',
        ],
        categoryId: electronics.id,
        storeId: store.id,
      },
    }),
    prisma.product.upsert({
      where: { slug: 'premium-cotton-tshirt' },
      update: {},
      create: {
        name: 'Premium Cotton T-Shirt',
        slug: 'premium-cotton-tshirt',
        description: 'Soft, breathable 100% organic cotton t-shirt. Available in multiple colors. Perfect for everyday wear.',
        price: 3500,
        comparePrice: 5000,
        stock: 200,
        images: [
          'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=600',
          'https://images.unsplash.com/photo-1503341504253-dff4815485f1?w=600',
        ],
        categoryId: fashion.id,
        storeId: store2.id,
      },
    }),
    prisma.product.upsert({
      where: { slug: 'classic-denim-jacket' },
      update: {},
      create: {
        name: 'Classic Denim Jacket',
        slug: 'classic-denim-jacket',
        description: 'Timeless denim jacket made from high-quality denim. Features classic button-up design with chest pockets.',
        price: 18000,
        comparePrice: 25000,
        stock: 45,
        images: [
          'https://images.unsplash.com/photo-1551537482-f2075a1d41f2?w=600',
        ],
        categoryId: fashion.id,
        storeId: store2.id,
      },
    }),
  ])

  console.log(`Created ${products.length} products`)

  // Add some reviews
  await prisma.review.createMany({
    skipDuplicates: true,
    data: [
      {
        userId: buyer.id,
        productId: products[0].id,
        rating: 5,
        comment: 'Excellent headphones! The noise cancellation is top-notch.',
      },
      {
        userId: buyer.id,
        productId: products[1].id,
        rating: 4,
        comment: 'Great smartwatch, battery life is impressive.',
      },
    ],
  })

  console.log('Seed completed successfully!')
  console.log('\nDemo accounts:')
  console.log('  Admin: admin@marketplace.com / admin123')
  console.log('  Vendor 1: vendor@techstore.com / vendor123')
  console.log('  Vendor 2: vendor@fashionboutique.com / vendor123')
  console.log('  Buyer: buyer@example.com / buyer123')
}

main()
  .then(async () => {
    await prisma.$disconnect()
  })
  .catch(async (e) => {
    console.error(e)
    await prisma.$disconnect()
    process.exit(1)
  })
