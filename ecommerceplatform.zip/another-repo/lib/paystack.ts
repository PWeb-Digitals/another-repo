const PAYSTACK_SECRET_KEY = process.env.PAYSTACK_SECRET_KEY!
const PAYSTACK_BASE_URL = 'https://api.paystack.co'

interface InitializeTransactionParams {
  email: string
  amount: number // in kobo (smallest currency unit)
  reference?: string
  callback_url?: string
  metadata?: Record<string, any>
}

interface InitializeTransactionResponse {
  status: boolean
  message: string
  data: {
    authorization_url: string
    access_code: string
    reference: string
  }
}

interface VerifyTransactionResponse {
  status: boolean
  message: string
  data: {
    id: number
    status: string
    reference: string
    amount: number
    paid_at: string
    customer: {
      email: string
    }
    metadata: Record<string, any>
  }
}

async function paystackRequest<T>(
  endpoint: string,
  method: 'GET' | 'POST' = 'GET',
  body?: Record<string, any>
): Promise<T> {
  const response = await fetch(`${PAYSTACK_BASE_URL}${endpoint}`, {
    method,
    headers: {
      Authorization: `Bearer ${PAYSTACK_SECRET_KEY}`,
      'Content-Type': 'application/json',
    },
    body: body ? JSON.stringify(body) : undefined,
  })

  if (!response.ok) {
    const error = await response.text()
    throw new Error(`Paystack API error: ${response.status} - ${error}`)
  }

  return response.json()
}

export async function initializeTransaction(
  params: InitializeTransactionParams
): Promise<InitializeTransactionResponse> {
  return paystackRequest<InitializeTransactionResponse>(
    '/transaction/initialize',
    'POST',
    {
      ...params,
      amount: params.amount * 100, // convert to kobo
    }
  )
}

export async function verifyTransaction(reference: string): Promise<VerifyTransactionResponse> {
  return paystackRequest<VerifyTransactionResponse>(
    `/transaction/verify/${reference}`
  )
}

export function generateReference(): string {
  const timestamp = Date.now()
  const random = Math.random().toString(36).substring(2, 8).toUpperCase()
  return `MKT-${timestamp}-${random}`
}
